# project_info.txt
print("He is a good boy")
print("HE is a working Professional")
